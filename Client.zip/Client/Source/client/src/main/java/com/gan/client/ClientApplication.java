package com.gan.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

@SpringBootApplication
public class ClientApplication {
	@Autowired
	ConnectServer connectServer;

	public static void main(String[] args) {
		SpringApplication.run(ClientApplication.class, args);
		client();
	}

	public static void client(){
		Scanner scanner = new Scanner(System.in);
		Map<String,String> ingMap=new HashMap<>();
		ingMap.put("1","cheese");
		ingMap.put("2","sausage");
		ingMap.put("3","mushroom");
		while(true) {
			System.out.println("Enter 1 to place an order: ");
			System.out.println("Enter 2 to Add oven by one: ");
			System.out.println("Enter 3 to get available ovens: ");
			System.out.println("Enter 4 to exit: ");

			String input = scanner.nextLine();
			if(input.equals("1")){
				System.out.println("Please select toppings");
				System.out.println("1) Cheese");
				System.out.println("2) Sausage");
				System.out.println("3) Mushrooms");
				String ing = scanner.nextLine();
				System.out.println("Select quantity");
				String qty = scanner.nextLine();
				System.out.println("");
				System.out.println(ConnectServer.placeOrder(ingMap.get(ing),Integer.parseInt(qty)));
				System.out.println("");

			}

			if(input.equals("3")){
				System.out.println("Available ovens "+ConnectServer.getOvens());
			}
			if(input.equals("4")){
				break;
			}
		}
		scanner.close();
		System.exit(0);
	}




}
