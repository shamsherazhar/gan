package com.gan.client;

import com.fasterxml.jackson.databind.JsonNode;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.*;

@Component
public class ConnectServer {
    static ExecutorService executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
    public static String placeOrder(String ing,int qty){
        String result1="";
        Future<String> result = executor.submit(new PostOrderImpl(ing,qty));
        try {
            result1=result.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return result1;
    }


    public static String getOvens(){
        RestTemplate restTemplate = new RestTemplate();
        String fooResourceUrl
                = "http://localhost:8080/pizzaorder/getOvens";
        ResponseEntity<String> response
                = restTemplate.getForEntity(fooResourceUrl, String.class);
        return response.getBody();
    }


}
