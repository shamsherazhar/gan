package com.gan.client;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.*;

public class PostOrderImpl  implements Callable<String> {
    String ing;
    int qty;

    public PostOrderImpl(String ing, int qty) {
        this.ing = ing;
        this.qty = qty;
    }

    @Override
    public String call() throws Exception {
        JSONObject personJsonObject = new JSONObject();

        try {
            personJsonObject.put("ingredient", ing);
            personJsonObject.put("qty", qty);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RestTemplate restTemplate = new RestTemplate();
        String fooResourceUrl
                = "http://localhost:8080/pizzaorder";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request =
                new HttpEntity<String>(personJsonObject.toString(), headers);

        String personResultAsJsonStr =
                restTemplate.postForObject(fooResourceUrl, request, String.class);

        return personResultAsJsonStr;
    }
}
