package com.gan.order.bean;

import com.gan.order.endpoints.pojo.OrderPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

@Component

public class IngredientsQuantity {
    private static Map<String, Integer> ingredientQtyMap = new HashMap<>();
    static BlockingQueue blockingDeque ;


    private  int QueueSize;

    private IngredientsQuantity() {

    }

    @Autowired
    private IngredientsQuantity(@Value("${pizza.order.ovens}") int QueueSize) {
        blockingDeque = new ArrayBlockingQueue(QueueSize);
    }

    @PostConstruct
    private static void init() throws Exception {
        System.out.print("Initialize");
        Properties properties = new Properties();
        File file = ResourceUtils.getFile("ingredients.csv");
        InputStream in = new FileInputStream(file);
        properties.load(in);
        parseMap(properties);

        printProperties();
    }

    public static void parseMap(Properties props) {
        Set<String> keys = props.stringPropertyNames();

        for (String key : keys) {
            if (key.contains("ingredient,"))
                continue;
            String value = key.replace(":", "");
            String[] valueArray = value.split(",");
            ingredientQtyMap.put(valueArray[0], Integer.parseInt(valueArray[1]));
        }
    }

    public Map<String ,Integer> getIngredientsMap() {
        return ingredientQtyMap;
    }

    public  Integer getIngredientsQuantity(String ingredients) {
        return ingredientQtyMap.get(ingredients);
    }

    public int  increaseOven(Integer ovens) {

        QueueSize=QueueSize+ovens;
            blockingDeque = new ArrayBlockingQueue(QueueSize);

        return blockingDeque.remainingCapacity();
    }

    public BlockingQueue<OrderPojo> getQueue() {
        return blockingDeque;
    }

    public Map updateIngredientsQuantity(String ingredients, Integer qty) {
        ingredientQtyMap.put(ingredients, ingredientQtyMap.get(ingredients) - qty);
        return ingredientQtyMap;
    }

    public static void printProperties() {
        System.out.println(ingredientQtyMap);
    }
}
