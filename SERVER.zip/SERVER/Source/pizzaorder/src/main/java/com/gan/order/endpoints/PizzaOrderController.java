package com.gan.order.endpoints;

import com.gan.order.endpoints.pojo.OrderPojo;
import com.gan.order.endpoints.pojo.OvenSize;
import com.gan.order.service.BakeOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;

@RestController
@RequestMapping("/pizzaorder")
public class PizzaOrderController {

    @Autowired
    BakeOrder bakeOrder;

    @PostMapping("")
    public String getOrder(@RequestBody @Valid OrderPojo orderPojo){
        if(!bakeOrder.addOrder(orderPojo)){
            return "Qty not enough, Please choose other ingredients";
        }
        return "Your "+orderPojo.getIngredient()+" pizza is ready";
    }

    @PostMapping("/addOvens")
    public int addOvers( @RequestBody @Valid   @Min(value = 1, message = "Quantity should not be less than 1") OvenSize ovenSize){

        return bakeOrder.aadOvens(ovenSize.getQty());
    }

    @GetMapping("/getOvens")
    public int getOvens( ){

        return bakeOrder.getOvens();
    }

}
