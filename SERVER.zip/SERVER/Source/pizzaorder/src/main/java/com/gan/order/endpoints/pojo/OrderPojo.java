package com.gan.order.endpoints.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Component
public class OrderPojo {
    @JsonProperty("ingredient")
    @NotEmpty(message = "Ingredient cannot be empty")
    private String ingredient;

    @NotNull(message = "Quantity cannot be empty")
    @Min(value = 1, message = "Quantity should not be less than 1")
    private Integer qty;

    public String getIngredient() {
        return ingredient;
    }

    public void setIngredient(String ingredient) {
        this.ingredient = ingredient;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }
}
