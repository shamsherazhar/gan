package com.gan.order.pizzaorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

@SpringBootApplication
@ComponentScan("com.gan.order")
public class PizzaorderApplication {

	public static void main(String[] args)  {
		SpringApplication.run(PizzaorderApplication.class, args);

	}

}
