package com.gan.order.service;

import com.gan.order.bean.IngredientsQuantity;
import com.gan.order.endpoints.pojo.OrderPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;



@Service
public class BakeOrder {

    @Autowired
    IngredientsQuantity ingredientsQuantity;

    private  int delay;

    @Autowired
    BakeOrder(@Value("${pizza.order.bakingtime}") int delay){
        this.delay=delay;
    }

    public  boolean addOrder(OrderPojo orderPojo){
        int qty=ingredientsQuantity.getIngredientsQuantity(orderPojo.getIngredient())-orderPojo.getQty();
        if(qty<0){
            return false;
        }
        try {
            ingredientsQuantity.updateIngredientsQuantity(orderPojo.getIngredient(),orderPojo.getQty());
            ingredientsQuantity.getQueue().put(orderPojo);
        }catch (Exception e){}
        bake();
        return true;
    }

    public String getQty(String ingredient){
        return ingredient+" "+ingredientsQuantity.getIngredientsQuantity(ingredient);
    }

    public Integer aadOvens(int qty){
        return ingredientsQuantity.increaseOven(qty);

    }

    public Integer getOvens(){
        return ingredientsQuantity.getQueue().remainingCapacity();

    }

    private void bake(){
        try{
            Thread.sleep(delay);
            OrderPojo orderPojo= ingredientsQuantity.getQueue().remove();

        }catch (Exception e){}
    }

}
