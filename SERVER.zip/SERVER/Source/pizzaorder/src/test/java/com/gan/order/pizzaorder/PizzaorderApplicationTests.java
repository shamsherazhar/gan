package com.gan.order.pizzaorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
